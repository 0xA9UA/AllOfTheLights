#!/bin/bash
# Finder opens executable .command files in Terminal on macOS.

TASK_DIR="$(cd -- "$(dirname -- "$0")" && pwd)" || exit 1
cd -- "$TASK_DIR" || exit 1

# Finder's Terminal PATH may not include an existing Homebrew Python.
TASK_PYTHON=""
for TASK_CANDIDATE in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    if [ -x "$TASK_CANDIDATE" ]; then
        TASK_PYTHON="$TASK_CANDIDATE"
        break
    fi
done
if [ -z "$TASK_PYTHON" ]; then
    TASK_PYTHON="$(command -v python3 2>/dev/null)"
fi
if [ -z "$TASK_PYTHON" ]; then
    printf '%s\n' 'Python 3 was not found.' 'Install Python 3 from https://www.python.org/downloads/macos/ or run your existing Python 3 interpreter with launch.py.'
    printf '%s\n' 'Press Return to close this window.'
    read -r
    exit 1
fi

"$TASK_PYTHON" "$TASK_DIR/launch.py" "$@"
TASK_RESULT=$?
if [ "$TASK_RESULT" -ne 0 ]; then
    printf '%s\n' 'The visualizer could not start. See the message above and README.html.' 'Press Return to close this window.'
    read -r
fi
exit "$TASK_RESULT"
