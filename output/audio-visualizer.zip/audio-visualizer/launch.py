#!/usr/bin/env python3
"""Serve the visualizer on this computer only; no packages are required."""

import argparse
import errno
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import threading
import webbrowser


APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"


class VisualizerHandler(SimpleHTTPRequestHandler):
    """Serve local assets without retaining stale versions in the browser."""

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        super().end_headers()

    def log_message(self, format, *args):
        # Routine file requests add no value during an event.
        if len(args) > 1 and str(args[1]).isdigit() and int(args[1]) >= 400:
            super().log_message(format, *args)


def open_browser(url):
    """Prefer Chrome on macOS, then use the user's default browser."""
    if sys.platform == "darwin":
        chrome_locations = (
            Path("/Applications/Google Chrome.app"),
            Path.home() / "Applications/Google Chrome.app",
        )
        if any(path.is_dir() for path in chrome_locations):
            try:
                result = subprocess.run(
                    ["open", "-a", "Google Chrome", url],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=10,
                )
                if result.returncode == 0:
                    return
            except (OSError, subprocess.TimeoutExpired):
                pass
    try:
        if webbrowser.open(url, new=2):
            return
    except webbrowser.Error:
        pass
    print("Browser did not open automatically. Paste the address above into Chrome.", flush=True)


def create_server(start_port):
    handler = partial(VisualizerHandler, directory=str(APP_DIR))
    for port in range(start_port, min(start_port + 100, 65536)):
        try:
            return ThreadingHTTPServer((HOST, port), handler)
        except OSError as error:
            if error.errno not in (errno.EADDRINUSE, errno.EACCES):
                raise
    raise OSError("No free local port found. Try: python3 launch.py --port 9000")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-browser", action="store_true", help="print the URL without opening a browser")
    parser.add_argument("--port", type=int, default=8765, help="first local port to try (default: 8765)")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("--port must be between 1024 and 65535")
    app_file = next((name for name in ("PULSE.html", "index.html") if (APP_DIR / name).is_file()), None)
    if app_file is None:
        print("PULSE.html is missing. Keep the visualizer HTML beside this launcher and try again.", file=sys.stderr)
        return 1
    try:
        server = create_server(args.port)
    except OSError as error:
        print("Unable to start the visualizer: {}".format(error), file=sys.stderr)
        return 1

    base_url = "http://{}:{}/".format(HOST, server.server_port)
    url = base_url + app_file
    print("\nAudio Visualizer\n", flush=True)
    print("Visuals: {}".format(url), flush=True)
    print("Mac setup guide: {}README.html".format(base_url), flush=True)
    print("\nChoose Microphone to react to your built-in or USB mic; allow audio access in the browser.", flush=True)
    print("For an optional direct copy of Mac playback, choose System audio and a configured loopback input.", flush=True)
    print("Keep this Terminal window open. Press Control-C here to stop the server.\n", flush=True)
    if not args.no_browser:
        threading.Thread(target=open_browser, args=(url,), daemon=True).start()
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        print("\nVisualizer server stopped. Your Mac's audio routing is unchanged.", flush=True)
        print("If you used a system-audio Multi-Output Device, restore your usual output in System Settings > Sound.", flush=True)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
